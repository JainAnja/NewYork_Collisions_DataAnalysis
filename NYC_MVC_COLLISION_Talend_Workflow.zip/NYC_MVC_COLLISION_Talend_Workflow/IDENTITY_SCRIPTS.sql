SET
IDENTITY_INSERT [dbo].[dim_arrest_borough] ON;
INSERT INTO [dbo].[dim_arrest_borough]
([borough_sk], [boro_code], [borough], [DI_JobID], [DI_Create_Date])



VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[dim_arrest_borough] OFF;
------------------- [dbo].[Dim_BODILY_INJURY] --------------------



SET
IDENTITY_INSERT [dbo].[Dim_BODILY_INJURY] ON;
INSERT INTO [dbo].[Dim_BODILY_INJURY]
([BODILY_INJURY_SK],[BODILY_INJURY],[DI_PID],[DI_Create_Date])



VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[Dim_BODILY_INJURY] OFF;




-------------------[dbo].[Dim_COMPLAINT] --------------------




SET
IDENTITY_INSERT [dbo].[Dim_COMPLAINT] ON;
INSERT INTO [dbo].[Dim_COMPLAINT]
([COMPLAINT_SK], [COMPLAINT], [DI_PID], [DI_Create_Date])




VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[Dim_COMPLAINT] OFF;





------------------- [dbo].[Dim_CONTRIBUTING_FACTOR] --------------------





SET
IDENTITY_INSERT [dbo].[Dim_CONTRIBUTING_FACTOR] ON;
INSERT INTO  [dbo].[Dim_CONTRIBUTING_FACTOR]
([CONTRIBUTING_FACTOR_SK], [CONTRIBUTING_FACTOR], [DI_PID], [DI_Create_Date])



VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT  [dbo].[Dim_CONTRIBUTING_FACTOR] OFF;






-------------------[dbo].[Dim_DRIVER_LICENSE_JURISDICTION]--------------------





SET
IDENTITY_INSERT [dbo].[Dim_DRIVER_LICENSE_JURISDICTION] ON;
INSERT INTO  [dbo].[Dim_DRIVER_LICENSE_JURISDICTION]
([DRIVER_LICENSE_JURISDICTION_SK], [DRIVER_LICENSE_JURISDICTION], [DI_PID], [DI_Create_Date])




VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT  [dbo].[Dim_DRIVER_LICENSE_JURISDICTION] OFF;




-------------------[dbo].[Dim_DRIVER_LICENSE_STATUS]-------------------





SET
IDENTITY_INSERT [dbo].[Dim_DRIVER_LICENSE_STATUS] ON;
INSERT INTO  [dbo].[Dim_DRIVER_LICENSE_STATUS]
([DRIVER_LICENSE_STATUS_SK], [DRIVER_LICENSE_STATUS], [DI_PID], [DI_Create_Date])




VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT  [dbo].[Dim_DRIVER_LICENSE_STATUS] OFF;




-------------------[dbo].[Dim_EJECTION]------------------





SET
IDENTITY_INSERT [dbo].[Dim_EJECTION] ON;
INSERT INTO  [dbo].[Dim_EJECTION]
([EJECTION_SK], [EJECTION], [DI_PID], [DI_Create_Date])



VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[Dim_EJECTION] OFF;




-------------------[dbo].[Dim_EMOTIONAL_STATUS]------------------





SET
IDENTITY_INSERT [dbo].[Dim_EMOTIONAL_STATUS] ON;
INSERT INTO  [dbo].[Dim_EMOTIONAL_STATUS]
([EMOTIONAL_STATUS_SK], [EMOTIONAL_STATUS], [DI_PID], [DI_Create_Date])




VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[Dim_EMOTIONAL_STATUS] OFF;





-------------------[dbo].[Dim_PED_ACTION]--------------------





SET
IDENTITY_INSERT [dbo].[Dim_PED_ACTION] ON;
INSERT INTO  [dbo].[Dim_PED_ACTION]
([PED_ACTION_SK], [PED_ACTION], [DI_PID], [DI_Create_Date])





VALUES
(-99,'No Value','ManualInput',getdate())
SET
IDENTITY_INSERT [dbo].[Dim_PED_ACTION] OFF;



------------------- PED_LOCATION --------------------



SET
IDENTITY_INSERT [dbo].[Dim_PED_LOCATION] on;



INSERT INTO [dbo].[Dim_PED_LOCATION]
([PED_LOCATION_SK],[PED_LOCATION],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PED_LOCATION] OFF;





---------------------- PED_ROLE ----------------------



SET
IDENTITY_INSERT [dbo].[Dim_PED_ROLE] on;



INSERT INTO [dbo].[Dim_PED_ROLE]
([PED_ROLE_SK],[PED_ROLE],[DI_PID],[DI_Create_Date])
VALUES (-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PED_ROLE] OFF;





-------------- PERSON_INJURY-----------------------



SET
IDENTITY_INSERT [dbo].[Dim_PERSON_INJURY] on;



INSERT INTO [dbo].[Dim_PERSON_INJURY]
([PERSON_INJURY_SK],[PERSON_INJURY],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PERSON_INJURY] OFF;




--------------- PERSON_SEX----------------------



SET
IDENTITY_INSERT [dbo].[Dim_PERSON_SEX] on;



INSERT INTO [dbo].[Dim_PERSON_SEX]
([PERSON_SEX_SK],[PERSON_SEX],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PERSON_SEX] OFF;




--------------------PERSONYPE---------------------



SET
IDENTITY_INSERT [dbo].[Dim_PersonType] on;



INSERT INTO [dbo].[Dim_PersonType]
([PERSON_TYPE_SK],[PERSON_TYPE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PersonType] OFF;




------------------POINT_OF_IMPACT-------------------



SET
IDENTITY_INSERT [dbo].[Dim_POINT_OF_IMPACT] on;



INSERT INTO [dbo].[Dim_POINT_OF_IMPACT]
([POINT_OF_IMPACT_SK],[POINT_OF_IMPACT],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_POINT_OF_IMPACT] OFF;




-------------------POSITION_IN_VEHICLE----------------



SET
IDENTITY_INSERT [dbo].[Dim_POSITION_IN_VEHICLE] on;



INSERT INTO [dbo].[Dim_POSITION_IN_VEHICLE]
([POSITION_IN_VEHICLE_SK],[POSITION_IN_VEHICLE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_POSITION_IN_VEHICLE] OFF;




----------------------PRE_CRASH------------------------



SET
IDENTITY_INSERT [dbo].[Dim_PRE_CRASH] on;



INSERT INTO [dbo].[Dim_PRE_CRASH]
([PRE_CRASH_SK],[PRE_CRASH],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PRE_CRASH] OFF;




--------------------PUBLIC_PROPERTY_DAMAGE--------------------



SET
IDENTITY_INSERT [dbo].[Dim_PUBLIC_PROPERTY_DAMAGE] on;



INSERT INTO [dbo].[Dim_PUBLIC_PROPERTY_DAMAGE]
([PUBLIC_PROPERTY_DAMAGE_SK],[PUBLIC_PROPERTY_DAMAGE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_PUBLIC_PROPERTY_DAMAGE];




--------------------SAFETY_EQUIPMENT--------------------



SET
IDENTITY_INSERT [dbo].[Dim_SAFETY_EQUIPMENT] on;



INSERT INTO [dbo].[Dim_SAFETY_EQUIPMENT]
([SAFETY_EQUIPMENT_SK],[SAFETY_EQUIPMENT],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_SAFETY_EQUIPMENT];




--------------------STATE_REGISTRATION--------------------



SET
IDENTITY_INSERT [dbo].[Dim_STATE_REGISTRATION] on;



INSERT INTO [dbo].[Dim_STATE_REGISTRATION]
([STATE_REGISTRATION_SK],[STATE_REGISTRATION],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_STATE_REGISTRATION];




--------------------TRAVEL_DIRECTION--------------------



SET
IDENTITY_INSERT [dbo].[Dim_TRAVEL_DIRECTION] on;



INSERT INTO [dbo].[Dim_TRAVEL_DIRECTION]
([TRAVEL_DIRECTION_SK],[TRAVEL_DIRECTION],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_TRAVEL_DIRECTION];





--------------------VEHICLE_DAMAGE--------------------



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_DAMAGE] on;



INSERT INTO [dbo].[Dim_VEHICLE_DAMAGE]
([VEHICLE_DAMAGE_SK],[VEHICLE_DAMAGE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_DAMAGE];





--------------------VEHICLE_MAKE--------------------



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_MAKE] on;



INSERT INTO [dbo].[Dim_VEHICLE_MAKE]
([VEHICLE_MAKE_SK],[VEHICLE_MAKE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_MAKE];





--------------------VEHICLE_MODEL--------------------



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_MODEL] on;



INSERT INTO [dbo].[Dim_VEHICLE_MODEL]
([VEHICLE_MODEL_SK],[VEHICLE_MAKE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_MODEL];




--------------------VEHICLE_TYPE--------------------



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_TYPE] on;



INSERT INTO [dbo].[Dim_VEHICLE_TYPE]
([VEHICLE_TYPE_SK],[VEHICLE_TYPE],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_VEHICLE_TYPE];




--------------------vehicle_type_code--------------------



SET
IDENTITY_INSERT [dbo].[Dim_vehicle_type_code] on;



INSERT INTO [dbo].[Dim_vehicle_type_code]
([vehicle_type_code_SK],[vehicle_type_code],[DI_PID],[DI_Create_Date])
VALUES(-99 , 'No Value', 'ManualInput', (getdate()));



SET
IDENTITY_INSERT [dbo].[Dim_vehicle_type_code];